package com.trsub.app

import okhttp3.Response

object Api {
    /** مدة الانتظار قبل إعادة المحاولة بعد خطأ 429 (تجاوز الحد). */
    fun retryDelayMs(resp: Response, attempt: Int): Long {
        val ra = resp.header("Retry-After")?.toDoubleOrNull()
        return if (ra != null) (ra * 1000).toLong().coerceIn(1000L, 30000L) else 5000L * attempt
    }
}
