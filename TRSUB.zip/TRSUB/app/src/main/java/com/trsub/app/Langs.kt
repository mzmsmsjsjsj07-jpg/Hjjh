package com.trsub.app

import com.google.mlkit.nl.translate.TranslateLanguage

class Lang(val code: String, val en: String, val ar: String, val ml: String)

object Langs {
    val all = listOf(
        Lang("ja", "Japanese", "اليابانية", TranslateLanguage.JAPANESE),
        Lang("en", "English", "الإنجليزية", TranslateLanguage.ENGLISH),
        Lang("ko", "Korean", "الكورية", TranslateLanguage.KOREAN),
        Lang("zh", "Chinese", "الصينية", TranslateLanguage.CHINESE),
        Lang("es", "Spanish", "الإسبانية", TranslateLanguage.SPANISH),
        Lang("fr", "French", "الفرنسية", TranslateLanguage.FRENCH),
        Lang("de", "German", "الألمانية", TranslateLanguage.GERMAN),
        Lang("ru", "Russian", "الروسية", TranslateLanguage.RUSSIAN),
        Lang("tr", "Turkish", "التركية", TranslateLanguage.TURKISH),
        Lang("it", "Italian", "الإيطالية", TranslateLanguage.ITALIAN),
        Lang("pt", "Portuguese", "البرتغالية", TranslateLanguage.PORTUGUESE),
        Lang("hi", "Hindi", "الهندية", TranslateLanguage.HINDI),
        Lang("id", "Indonesian", "الإندونيسية", TranslateLanguage.INDONESIAN),
        Lang("th", "Thai", "التايلاندية", TranslateLanguage.THAI),
        Lang("vi", "Vietnamese", "الفيتنامية", TranslateLanguage.VIETNAMESE)
    )

    /** يبحث بالاسم الإنجليزي (كما يرجعه Whisper) أو برمز اللغة. */
    fun find(name: String): Lang? {
        val n = name.lowercase().trim()
        if (n.isEmpty()) return null
        return all.firstOrNull { it.code == n || it.en.lowercase() == n }
    }
}
